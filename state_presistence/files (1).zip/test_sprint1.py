"""
Test script for ML Verse Sprint 1 - State Persistence
Tests WorkspaceManager operations with proper error handling
"""

import os
import json
import shutil
from workspace_manager import WorkspaceManager


def print_section(title):
    """Print formatted section header"""
    print(f"\n{'=' * 70}")
    print(f"🧪 {title}")
    print(f"{'=' * 70}\n")


def test_create_workspace():
    """Test: Create workspace with all files"""
    print_section("TEST 1: Create Workspace")
    
    manager = WorkspaceManager(workspace_root="test_workspace", max_workspaces=5)
    
    try:
        path = manager.create_workspace("testuser", "TestWorkspace")
        
        # Verify folder structure
        assert os.path.exists(path), "Workspace path not created"
        assert os.path.exists(os.path.join(path, "metadata.json")), "metadata.json not created"
        assert os.path.exists(os.path.join(path, "state.json")), "state.json not created"
        assert os.path.exists(os.path.join(path, "pipeline.json")), "pipeline.json not created"
        
        # Verify folders
        folders = ["data", "preprocessing", "models", "results", "reports", "logs", "versions"]
        for folder in folders:
            folder_path = os.path.join(path, folder)
            assert os.path.exists(folder_path), f"Folder '{folder}' not created"
        
        # Load and verify content
        with open(os.path.join(path, "metadata.json")) as f:
            metadata = json.load(f)
            assert metadata["workspace_name"] == "TestWorkspace"
            assert metadata["owner"] == "testuser"
        
        with open(os.path.join(path, "state.json")) as f:
            state = json.load(f)
            assert state["current_step"] == "dataset_upload"
            assert state["dataset_uploaded"] == False
        
        with open(os.path.join(path, "pipeline.json")) as f:
            pipeline = json.load(f)
            assert pipeline["target_column"] is None
        
        print("✅ Workspace created successfully")
        print(f"   Path: {path}")
        print(f"   Files: metadata.json, state.json, pipeline.json")
        print(f"   Folders: {', '.join(folders)}")
        return path
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")
        return None


def test_load_workspace(manager, workspace_path):
    """Test: Load workspace with all files"""
    print_section("TEST 2: Load Workspace")
    
    try:
        # Get workspace info from path
        workspace_name = os.path.basename(workspace_path)
        user = "testuser"
        
        # Load workspace
        data = manager.load_workspace(user, workspace_name)
        
        assert "metadata" in data, "metadata not in loaded data"
        assert "state" in data, "state not in loaded data"
        assert "pipeline" in data, "pipeline not in loaded data"
        assert "workspace_path" in data, "workspace_path not in loaded data"
        
        print("✅ Workspace loaded successfully")
        print(f"   Metadata: {data['metadata']['workspace_name']}")
        print(f"   Current Step: {data['state']['current_step']}")
        print(f"   Pipeline Sections: {len(data['pipeline'])} configured")
        return data
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")
        return None


def test_update_state(manager, workspace_path):
    """Test: Update state.json"""
    print_section("TEST 3: Update State")
    
    try:
        # Update multiple state fields
        manager.update_state(workspace_path, "dataset_uploaded", True)
        manager.update_state(workspace_path, "current_step", "missing_values")
        manager.update_state(workspace_path, "dataset_status", "valid")
        
        # Load and verify
        with open(os.path.join(workspace_path, "state.json")) as f:
            state = json.load(f)
            assert state["dataset_uploaded"] == True
            assert state["current_step"] == "missing_values"
            assert state["dataset_status"] == "valid"
        
        print("✅ State updated successfully")
        print(f"   dataset_uploaded: {state['dataset_uploaded']}")
        print(f"   current_step: {state['current_step']}")
        print(f"   dataset_status: {state['dataset_status']}")
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")


def test_update_pipeline(manager, workspace_path):
    """Test: Update pipeline.json"""
    print_section("TEST 4: Update Pipeline")
    
    try:
        # Update pipeline sections
        manager.update_pipeline(workspace_path, "remove_columns", ["ID", "Phone"])
        manager.update_pipeline(workspace_path, "missing_values", {
            "Age": "mean",
            "Salary": "median"
        })
        manager.update_pipeline(workspace_path, "encoding", {
            "Gender": "label",
            "Country": "onehot"
        })
        manager.update_pipeline(workspace_path, "target_column", "Disease")
        
        # Load and verify
        with open(os.path.join(workspace_path, "pipeline.json")) as f:
            pipeline = json.load(f)
            assert pipeline["remove_columns"] == ["ID", "Phone"]
            assert "Age" in pipeline["missing_values"]
            assert "Gender" in pipeline["encoding"]
            assert pipeline["target_column"] == "Disease"
        
        print("✅ Pipeline updated successfully")
        print(f"   remove_columns: {pipeline['remove_columns']}")
        print(f"   missing_values: {pipeline['missing_values']}")
        print(f"   encoding: {pipeline['encoding']}")
        print(f"   target_column: {pipeline['target_column']}")
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")


def test_list_workspaces(manager):
    """Test: List workspaces"""
    print_section("TEST 5: List Workspaces")
    
    try:
        workspaces = manager.list_workspaces("testuser")
        
        assert "TestWorkspace" in workspaces, "Workspace not in list"
        assert "workspace_id" in workspaces["TestWorkspace"]
        assert "workspace_path" in workspaces["TestWorkspace"]
        
        print("✅ Workspaces listed successfully")
        for name, info in workspaces.items():
            print(f"   {name}")
            print(f"      ID: {info['workspace_id']}")
            print(f"      Status: {info['status']}")
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")


def test_rename_workspace(manager):
    """Test: Rename workspace"""
    print_section("TEST 6: Rename Workspace")
    
    try:
        manager.rename_workspace("testuser", "TestWorkspace", "RenamedWorkspace")
        
        workspaces = manager.list_workspaces("testuser")
        assert "RenamedWorkspace" in workspaces, "Renamed workspace not found"
        assert "TestWorkspace" not in workspaces, "Old name still exists"
        
        # Verify metadata was updated
        new_path = workspaces["RenamedWorkspace"]["workspace_path"]
        with open(os.path.join(new_path, "metadata.json")) as f:
            metadata = json.load(f)
            assert metadata["workspace_name"] == "RenamedWorkspace"
        
        print("✅ Workspace renamed successfully")
        print(f"   Old name: TestWorkspace")
        print(f"   New name: RenamedWorkspace")
        print(f"   Metadata updated: {metadata['workspace_name']}")
        
        return "RenamedWorkspace"
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")
        return None


def test_persistence(manager):
    """Test: Verify persistence across load"""
    print_section("TEST 7: Verify Persistence")
    
    try:
        # Load workspace again
        data = manager.load_workspace("testuser", "RenamedWorkspace")
        
        # Verify state persisted
        assert data["state"]["dataset_uploaded"] == True, "State not persisted"
        assert data["state"]["current_step"] == "missing_values", "Current step not persisted"
        
        # Verify pipeline persisted
        assert data["pipeline"]["remove_columns"] == ["ID", "Phone"], "Pipeline not persisted"
        assert data["pipeline"]["target_column"] == "Disease", "Target column not persisted"
        
        print("✅ Persistence verified")
        print(f"   State: {data['state']['current_step']} (persisted)")
        print(f"   Pipeline config: Complete (persisted)")
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")


def test_error_handling_strict():
    """Test: STRICT error handling (workspace files)"""
    print_section("TEST 8: STRICT Error Handling")
    
    manager = WorkspaceManager(workspace_root="test_workspace")
    
    try:
        # Try to load non-existent workspace
        try:
            manager.load_workspace("testuser", "NonExistent")
            print("❌ Should have raised ValueError")
        except ValueError:
            print("✅ ValueError raised for non-existent workspace (STRICT)")
        
        # Try to update non-existent workspace
        try:
            manager.update_state("non/existent/path", "dataset_uploaded", True)
            print("❌ Should have raised FileNotFoundError")
        except FileNotFoundError:
            print("✅ FileNotFoundError raised for missing state.json (STRICT)")
        
        # Try invalid state key
        workspaces = manager.list_workspaces("testuser")
        if workspaces:
            workspace_path = list(workspaces.values())[0]["workspace_path"]
            try:
                manager.update_state(workspace_path, "invalid_key", True)
                print("❌ Should have raised ValueError")
            except ValueError:
                print("✅ ValueError raised for invalid state key (STRICT)")
        
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")


def test_max_workspaces(manager):
    """Test: Maximum workspace limit"""
    print_section("TEST 9: Maximum Workspace Limit")
    
    try:
        manager_limited = WorkspaceManager(workspace_root="test_workspace", max_workspaces=2)
        
        # Already have 1 workspace (RenamedWorkspace)
        # Try to create one more (should succeed)
        path = manager_limited.create_workspace("testuser", "SecondWorkspace")
        assert os.path.exists(path), "Second workspace not created"
        print("✅ Second workspace created (limit = 2, now have 2)")
        
        # Try to create third (should fail)
        try:
            manager_limited.create_workspace("testuser", "ThirdWorkspace")
            print("❌ Should have raised ValueError for max workspaces")
        except ValueError as e:
            print(f"✅ ValueError raised for max workspace limit: {str(e)}")
        
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")


def test_delete_workspace(manager):
    """Test: Delete workspace"""
    print_section("TEST 10: Delete Workspace")
    
    try:
        # Delete workspace
        manager.delete_workspace("testuser", "SecondWorkspace")
        
        workspaces = manager.list_workspaces("testuser")
        assert "SecondWorkspace" not in workspaces, "Workspace still in index"
        
        print("✅ Workspace deleted successfully")
        print(f"   Deleted from index and filesystem")
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")


def cleanup():
    """Clean up test workspace"""
    print_section("CLEANUP")
    
    if os.path.exists("test_workspace"):
        shutil.rmtree("test_workspace")
        print("✅ Test workspace cleaned up")


def run_all_tests():
    """Run all tests"""
    print("\n" + "=" * 70)
    print("🚀 ML VERSE V2 - SPRINT 1 TEST SUITE")
    print("=" * 70)
    
    manager = WorkspaceManager(workspace_root="test_workspace", max_workspaces=5)
    
    # Run tests in sequence
    workspace_path = test_create_workspace()
    if not workspace_path:
        print("\n❌ Cannot continue without workspace")
        return
    
    data = test_load_workspace(manager, workspace_path)
    if not data:
        print("\n❌ Cannot continue without loading workspace")
        return
    
    test_update_state(manager, workspace_path)
    test_update_pipeline(manager, workspace_path)
    test_list_workspaces(manager)
    renamed = test_rename_workspace(manager)
    if renamed:
        test_persistence(manager)
    
    test_error_handling_strict()
    test_max_workspaces(manager)
    test_delete_workspace(manager)
    
    cleanup()
    
    print("\n" + "=" * 70)
    print("✅ ALL TESTS COMPLETED")
    print("=" * 70)
    print("\nSprint 1 Implementation: READY FOR PRODUCTION ✨\n")


if __name__ == "__main__":
    run_all_tests()
